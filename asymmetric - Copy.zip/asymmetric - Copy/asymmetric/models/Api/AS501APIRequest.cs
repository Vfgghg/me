﻿using AS501client;
using RES_LEARN;
using System;
using System.Net.Http;
using System.Reflection.Emit;

public class AS501APIRequest
{
    public static async Task Main(string[] args)
    {
        MainRequestDataField requestData = CreateRequestData();
    
        byte[] encryptedData = Encryption.Encrypt(requestData)
        byte[] signature = Signature.SignData(encryptedData);
        HttpResponseMessage response = await AS501client1.SendRequestToApi(encryptedData, signature);
        await AS501APIResponse.ProcessResponse(response);
    }

    private static MainRequestDataField CreateRequestData()
    {
        return new MainRequestDataField
        {
            RequestedID = "123456",
            SourceSystemName = "SourceSysTEM",
            ApiToken = "your_api_token",
            Purpose = "Purpose1",
            SessionKey = "session_key"
        };
    }
}
