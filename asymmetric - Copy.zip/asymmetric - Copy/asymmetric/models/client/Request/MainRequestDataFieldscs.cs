﻿using System;
using static MainRequestDataField;
public class MainRequestDataField
{
    public string RequestedID { get; set; }
    public string SourceSystemName { get; set; }
    public string ApiToken { get; set; }
    public string Purpose { get; set; }
    public string SessionKey { get; set; }
}
   
