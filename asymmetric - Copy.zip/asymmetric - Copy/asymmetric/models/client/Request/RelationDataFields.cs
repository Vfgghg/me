﻿using System;
using static RelationDataFields;

public class RelationDataFields 
{
    public string CustomerSourceSystemCode { get; set; }
    public string RelatedPersonSourceSystemCode { get; set; }
    public string RelationCode { get; set; }
    public string RelationStartDate { get; set; }
    public string RelationEndDate { get; set; }
    public string ShareHoldingPercentage { get; set; }
    public string RelationNotes { get; set; }

}