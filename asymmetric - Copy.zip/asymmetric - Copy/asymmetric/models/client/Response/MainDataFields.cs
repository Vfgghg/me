﻿using System;
using static MainDataFields;

public class MainDataFields
{
    public string RequestId { get; set; }
    public string ValidationCode { get; set; }
    public string ValidationDescription { get; set; }
    public string OverallStatus { get; set; }

}