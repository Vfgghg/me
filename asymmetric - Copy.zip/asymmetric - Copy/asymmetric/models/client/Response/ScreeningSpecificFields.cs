﻿using System;
using static ScreeningSpecificFields;
public class ScreeningSpecificFields
{
    public string SourceSystemCustomerCode { get; set; }
    public string ValidationOutcome { get; set; }
    public string Purpose { get; set; }
    public string PurposeCode { get; set; }
    public string ValidationCode { get; set; }
    public string ValidationDescription { get; set; }
    public string ValidationFailureCount { get; set; }
    public string HitsDetected { get; set; }
    public string HitsCount { get; set; }
    public string CaseId { get; set; }
    public string CaseURL { get; set; }
    public string ConfirmedHit { get; set; }
    public string SuggestedAction { get; set; }
    public string ReportData { get; set; }
    public string Source { get; set; }
    public string WatchlistSourceID { get; set; }
    public string MatchType { get; set; }
    public string Score { get; set; }
    public string ConfirmedMatchingAttributes { get; set; }
}

