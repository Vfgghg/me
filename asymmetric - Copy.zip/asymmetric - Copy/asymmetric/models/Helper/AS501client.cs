﻿using RES_LEARN;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace AS501client
{
    class AS501client1
    {
        static void Main(string[] args)
        {

            string publicKeyCertificatePath = "H:\\Temporary\\Vaibhav.Soni\\Marwadi\\server\\public.cer";
            string privateKeyCertificatePath = "H:\\Temporary\\Vaibhav.Soni\\Marwadi\\server\\private.pfx";
            string privateKeyCertificatePassword = "test@123";
            // Load public key certificate
            X509Certificate2 publicKeyCertificate = new X509Certificate2(publicKeyCertificatePath);

            // Load private key certificate
            X509Certificate2 privateKeyCertificate = new X509Certificate2(privateKeyCertificatePath, privateKeyCertificatePassword, X509KeyStorageFlags.Exportable | X509KeyStorageFlags.MachineKeySet);

            // Extract RSA parameters from certificate
            RSAParameters publicKeyParameters = ((RSA)publicKeyCertificate.GetRSAPublicKey()).ExportParameters(false);
            RSAParameters privateKeyParameters = ((RSA)privateKeyCertificate.GetRSAPrivateKey()).ExportParameters(true);

            string textToEncrypt = GenerateTestString();
            Console.WriteLine("TEXT TO ENCRYPT: ");
            Console.WriteLine(textToEncrypt);
            Console.WriteLine("-------------------------------------------");

            // Sign the data before encryption
            byte[] signature = Signature.SignData(Encoding.UTF8.GetBytes(textToEncrypt), privateKeyCertificate);

            byte[] encryptedBytes = Encryption.Encrypt(Encoding.UTF8.GetBytes(textToEncrypt), publicKeyParameters);
            string encryptedText = Convert.ToBase64String(encryptedBytes);
            Console.WriteLine("ENCRYPTED TEXT: ");
            Console.WriteLine(encryptedText);
            Console.WriteLine("-------------------------------------------");

            string decryptedText = Decryption.Decrypt(Convert.FromBase64String(encryptedText), privateKeyParameters);
            // Verify the signature after decryption
            bool signatureValid = Signature.VerifySignature(Encoding.UTF8.GetBytes(decryptedText), signature, publicKeyCertificate);
            Console.WriteLine("SIGNATURE VALIDITY: ");
            Console.WriteLine(signatureValid ? "Valid" : "Invalid");
            Console.WriteLine("-------------------------------------------");

            Console.WriteLine("DECRYPTED TEXT: ");
            Console.WriteLine(decryptedText);

            Console.WriteLine("press any key to exit");
            Console.ReadKey();
        }

        private static string GenerateTestString()
        {
            Guid opportunityId = Guid.NewGuid();
            Guid systemUserId = Guid.NewGuid();
            string currentTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("opportunityid={0}", opportunityId.ToString());
            sb.AppendFormat("&systemuserid={0}", systemUserId.ToString());
            sb.AppendFormat("&currenttime={0}", currentTime);

            return sb.ToString();
        }
    }
}




          