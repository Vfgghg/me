﻿using System;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace RES_LEARN
{
    public static class Encryption
    {
        public static byte[] Encrypt(byte[] data, RSAParameters publicKeyParameters)
        {
            using (RSA rsa = RSA.Create())
            {
                rsa.ImportParameters(publicKeyParameters);
                return rsa.Encrypt(data, RSAEncryptionPadding.OaepSHA256);
            }
        }
        public static string GetKeyString(RSAParameters publicKey)
        {
            var stringWriter = new StringWriter();
            var xmlSerializer = new System.Xml.Serialization.XmlSerializer(typeof(RSAParameters));
            xmlSerializer.Serialize(stringWriter, publicKey);
            return stringWriter.ToString();
        }
    }
}
