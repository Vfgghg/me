﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace RES_LEARN
{
    public static class Decryption
    {
        public static string Decrypt(byte[] encryptedData, RSAParameters privateKeyParameters)
        {
            using (RSA rsa = RSA.Create())
            {
                rsa.ImportParameters(privateKeyParameters);
                byte[] decryptedData = rsa.Decrypt(encryptedData, RSAEncryptionPadding.OaepSHA256);
                return Encoding.UTF8.GetString(decryptedData);
            }
        }
    }
}
