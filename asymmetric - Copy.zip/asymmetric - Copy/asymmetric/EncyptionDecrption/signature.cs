﻿using System;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace RES_LEARN
{
    public static class Signature
    {
        // Signs the provided data using RSA signature
        public static byte[] SignData(byte[] data, X509Certificate2 certificate)
        {
            using (RSA rsa = (RSA)certificate.GetRSAPrivateKey())
            {
                return rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
        }

        public static bool VerifySignature(byte[] data, byte[] signature, X509Certificate2 certificate)
        {
            using (RSA rsa = (RSA)certificate.GetRSAPublicKey())
            {
                return rsa.VerifyData(data, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
        }
    }
}
